#ifndef BOXDROP_SERVER_H
#define BOXDROP_SERVER_H

#include "local.h"
#include "folderhandler.h"

#endif
