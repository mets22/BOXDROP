
#ifndef BOXDROP_CLIENT_H
#define BOXDROP_CLIENT_H

#include "local.h"
#include "folderhandler.h"

#endif
